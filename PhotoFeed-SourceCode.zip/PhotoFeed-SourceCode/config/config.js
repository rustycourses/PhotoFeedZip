import firebase from 'firebase';

const config = {
  apiKey: "---",
  authDomain: "photo-feed----.firebaseapp.com",
  databaseURL: "https://photo-feed------.firebaseio.com",
  projectId: "-------",
  storageBucket: "photo-feed----.appspot.com",
  messagingSenderId: "---"
};
firebase.initializeApp(config);

export const f = firebase;
export const database = firebase.database();
export const auth = firebase.auth();
export const storage = firebase.storage();
